#!C:/Python33/python.exe -u

print ("Content-type: text/html\n\n"); 
print ("Hello World! <br><br>"); 
