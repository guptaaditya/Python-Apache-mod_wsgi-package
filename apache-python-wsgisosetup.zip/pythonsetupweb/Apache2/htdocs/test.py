#!C:/Python33/python.exe -u
print("hello world");